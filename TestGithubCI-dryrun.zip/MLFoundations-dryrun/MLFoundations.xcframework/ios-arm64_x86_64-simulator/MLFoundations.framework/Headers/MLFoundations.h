//
//  MLFoundations.h
//  MLFoundations
//
//  Created by Guanyu He on 2/18/22.
//

#import <Foundation/Foundation.h>

//! Project version number for MLFoundations.
FOUNDATION_EXPORT double MLFoundationsVersionNumber;

//! Project version string for MLFoundations.
FOUNDATION_EXPORT const unsigned char MLFoundationsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MLFoundations/PublicHeader.h>


