//
//  TestXCFramework.h
//  TestXCFramework
//
//  Created by Guanyu He on 11/18/21.
//

#import <Foundation/Foundation.h>

//! Project version number for TestXCFramework.
FOUNDATION_EXPORT double TestXCFrameworkVersionNumber;

//! Project version string for TestXCFramework.
FOUNDATION_EXPORT const unsigned char TestXCFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestXCFramework/PublicHeader.h>


