//
//  Core.h
//  Core
//
//  Created by Guanyu He on 2/18/22.
//

#import <Foundation/Foundation.h>

//! Project version number for Core.
FOUNDATION_EXPORT double CoreVersionNumber;

//! Project version string for Core.
FOUNDATION_EXPORT const unsigned char CoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Core/PublicHeader.h>


